import { Component, OnInit } from '@angular/core';
import { Product } from '../model/product.model';
import { ProductService } from '../service/product.service';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {
  prodC: Product["cname"];
  productData: any;
  productList: Product[];
  constructor(private ps : ProductService) { }

  ngOnInit(): void {
    this.getPostList(this.prodC);
  }
   
  getPostList(prodC) {
    this.ps.getCatDetails(prodC).subscribe(data => {
      this.productList = data;
      console.log(data);
    });
}

}

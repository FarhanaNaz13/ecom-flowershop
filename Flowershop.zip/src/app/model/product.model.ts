export class Product {
    id;
    availability;
    description;
    name;
    price;
    qty;
    photo;
    cname;
    constructor(id,availability,description,name,photo,price,qty,cname){
        this.id=id;
        this.availability=availability;
        this.description=description;
        this.name=name;
        this.photo=photo;
        this.price=price;
        this.qty=qty;
        this.cname=cname;
        
    }
    
}

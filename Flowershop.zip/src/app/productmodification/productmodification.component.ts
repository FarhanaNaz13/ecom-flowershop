import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productmodification',
  templateUrl: './productmodification.component.html',
  styleUrls: ['./productmodification.component.css']
})
export class ProductmodificationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
